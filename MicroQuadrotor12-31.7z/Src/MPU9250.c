/**
  ******************************************************************************
  * @file    MPU9250.c
  * @author  
  * @version V1.0
  * @date    2015.4.2
  * @note
  * @history    V1.0 2015.4.2
  *                 Set up a basic framwork.
  ******************************************************************************
  */
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "MPU9250.h"
#include "bsp.h"


//������ر���


MPU9250_Raw_Data  g_Raw_Data;
