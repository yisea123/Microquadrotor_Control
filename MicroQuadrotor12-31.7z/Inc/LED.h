#ifndef _LED_H_
#define _LED_H_

#include "bsp.h"
void BigLed(u32 i);
void LedHandle(void);
extern u32 StatusLedOn;
#endif
