#ifndef _OBSTACLES_H_
#define _OBSTACLES_H_

#include "bsp.h"
#include "adc.h"
extern float PitchObstacle,RollObstacle;
void ObstaclesHandler(void);
#endif
